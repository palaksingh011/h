import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { 
  Heart, 
  ArrowLeft, 
  User, 
  Lock, 
  Eye, 
  EyeOff,
  LogIn,
  UserPlus,
  Clock,
  Users
} from 'lucide-react'

const PatientLogin = () => {
  const [isLogin, setIsLogin] = useState(true)
  const [showPassword, setShowPassword] = useState(false)
  const [recentPatients, setRecentPatients] = useState([])
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    password: '',
    confirmPassword: ''
  })

  // Load recently added patients from staff
  useEffect(() => {
    const loadRecentPatients = () => {
      const queuePatients = JSON.parse(localStorage.getItem('queuePatients') || '[]')
      // Only show patients who are waiting (not called or completed)
      const waitingPatients = queuePatients.filter(p => p.status === 'waiting')
      setRecentPatients(waitingPatients.slice(-5)) // Show last 5 waiting patients
    }
    
    loadRecentPatients()
    
    // Refresh every 5 seconds to update when patients are called
    const interval = setInterval(loadRecentPatients, 5000)
    return () => clearInterval(interval)
  }, [])

  const handleSubmit = (e) => {
    e.preventDefault()
    if (isLogin) {
      // Simulate login
      localStorage.setItem('patientData', JSON.stringify({
        name: formData.name,
        phone: formData.phone,
        email: formData.email,
        loginTime: new Date().toISOString()
      }))
      window.location.href = '/patient'
    } else {
      // Simulate registration
      if (formData.password !== formData.confirmPassword) {
        alert('Passwords do not match!')
        return
      }
      localStorage.setItem('patientData', JSON.stringify({
        name: formData.name,
        phone: formData.phone,
        email: formData.email,
        loginTime: new Date().toISOString()
      }))
      alert('Account created successfully! You are now logged in.')
      window.location.href = '/patient'
    }
  }

  const handleQuickLogin = (patient) => {
    localStorage.setItem('patientData', JSON.stringify({
      name: patient.name,
      phone: patient.phone,
      email: `${patient.name.toLowerCase().replace(' ', '.')}@example.com`,
      loginTime: new Date().toISOString()
    }))
    window.location.href = '/patient'
  }

  const refreshRecentPatients = () => {
    const queuePatients = JSON.parse(localStorage.getItem('queuePatients') || '[]')
    const waitingPatients = queuePatients.filter(p => p.status === 'waiting')
    setRecentPatients(waitingPatients.slice(-5))
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        {/* Header */}
        <div className="text-center">
          <Link to="/" className="flex items-center justify-center mb-6">
            <ArrowLeft className="h-5 w-5 text-gray-600 mr-2" />
            <Heart className="h-8 w-8 text-primary-600 mr-2" />
            <span className="text-2xl font-bold text-gray-900">MediQ</span>
          </Link>
          <h2 className="text-3xl font-bold text-gray-900">
            {isLogin ? 'Welcome Back' : 'Create Account'}
          </h2>
          <p className="mt-2 text-sm text-gray-600">
            {isLogin 
              ? 'Sign in to access your medical appointments and queue status'
              : 'Join MediQ to manage your hospital visits seamlessly'
            }
          </p>
        </div>

        {/* Form */}
        <div className="card">
          <form className="space-y-6" onSubmit={handleSubmit}>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Full Name
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="pl-10 input-field"
                  placeholder="Enter your full name"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Phone Number
              </label>
              <input
                type="tel"
                required
                value={formData.phone}
                onChange={(e) => setFormData({...formData, phone: e.target.value})}
                className="input-field"
                placeholder="+91 98765 43210"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email Address
              </label>
              <input
                type="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                className="input-field"
                placeholder="your.email@example.com"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={formData.password}
                  onChange={(e) => setFormData({...formData, password: e.target.value})}
                  className="pl-10 pr-10 input-field"
                  placeholder="Enter your password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
            </div>

            {!isLogin && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Confirm Password
                </label>
                <input
                  type="password"
                  required
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                  className="input-field"
                  placeholder="Confirm your password"
                />
              </div>
            )}

            <button
              type="submit"
              className="btn-primary w-full"
            >
              {isLogin ? (
                <>
                  <LogIn className="h-5 w-5 mr-2" />
                  Sign In
                </>
              ) : (
                <>
                  <UserPlus className="h-5 w-5 mr-2" />
                  Create Account
                </>
              )}
            </button>
          </form>

          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">
                  {isLogin ? "Don't have an account?" : "Already have an account?"}
                </span>
              </div>
            </div>

            <div className="mt-6">
              <button
                onClick={() => setIsLogin(!isLogin)}
                className="btn-secondary w-full"
              >
                {isLogin ? 'Create New Account' : 'Sign In Instead'}
              </button>
            </div>
          </div>
        </div>

        {/* Recently Added Patients */}
        {recentPatients.length > 0 && (
          <div className="card bg-green-50 border-green-200">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center">
                <Users className="h-5 w-5 text-green-600 mr-2" />
                <h3 className="text-sm font-medium text-green-900">Recently Added Patients</h3>
              </div>
              <button
                onClick={refreshRecentPatients}
                className="text-green-600 hover:text-green-700 text-xs"
              >
                Refresh
              </button>
            </div>
            <p className="text-xs text-green-700 mb-3">
              These patients were recently added to the queue by staff. Click to login as them:
            </p>
        <div className="space-y-2">
          {recentPatients.map((patient, index) => (
            <div 
              key={index}
              onClick={() => handleQuickLogin(patient)}
              className="flex items-center justify-between p-2 bg-white rounded-lg border border-green-200 cursor-pointer hover:bg-green-100 transition-colors"
            >
              <div className="flex items-center">
                <div className={`w-2 h-2 rounded-full mr-2 ${
                  patient.priority === 'urgent' ? 'bg-red-500' :
                  patient.priority === 'emergency' ? 'bg-red-600' : 'bg-green-500'
                }`} />
                <div>
                  <div className="text-sm font-medium text-gray-900">{patient.name}</div>
                  <div className="text-xs text-gray-600">{patient.department} • {patient.token}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs text-gray-500">{patient.waitTime} min wait</div>
                <div className="text-xs text-green-600">Click to login</div>
              </div>
            </div>
          ))}
          {recentPatients.length === 0 && (
            <div className="text-center py-4 text-gray-500 text-sm">
              No patients currently waiting
            </div>
          )}
        </div>
          </div>
        )}

        {/* Demo Credentials */}
        <div className="card bg-blue-50 border-blue-200">
          <h3 className="text-sm font-medium text-blue-900 mb-2">Demo Credentials</h3>
          <div className="text-xs text-blue-700 space-y-1">
            <div><strong>Name:</strong> Rajesh Kumar</div>
            <div><strong>Phone:</strong> +91 98765 43210</div>
            <div><strong>Email:</strong> rajesh@example.com</div>
            <div><strong>Password:</strong> password123</div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default PatientLogin

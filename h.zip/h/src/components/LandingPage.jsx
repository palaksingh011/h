import { useState } from 'react'
import { Link } from 'react-router-dom'
import { 
  Heart, 
  Clock, 
  Users, 
  Smartphone, 
  ArrowRight, 
  CheckCircle,
  Star,
  Zap,
  Shield,
  BarChart3
} from 'lucide-react'

const LandingPage = () => {
  const [activeFeature, setActiveFeature] = useState(0)

  const features = [
    {
      icon: <Zap className="h-8 w-8 text-primary-600" />,
      title: "Intelligent Scheduling",
      description: "AI analyzes hospital data to assign the most accurate appointment time, minimizing wait from the start."
    },
    {
      icon: <Smartphone className="h-8 w-8 text-medical-600" />,
      title: "Virtual Check-in & Real-Time Updates",
      description: "Patients check in on the app and can wait anywhere, receiving real-time updates about their queue position."
    },
    {
      icon: <Users className="h-8 w-8 text-emergency-600" />,
      title: "Multi-Departmental Flow",
      description: "Manage a patient's entire journey from doctor to diagnostics lab to pharmacy, managing every sub-queue."
    },
    {
      icon: <BarChart3 className="h-8 w-8 text-primary-600" />,
      title: "Staff Empowerment",
      description: "Comprehensive dashboard for hospital staff to manage queues, optimize resources, and improve patient flow."
    }
  ]

  const stats = [
    { number: "75%", label: "Reduction in Wait Time" },
    { number: "90%", label: "Patient Satisfaction" },
    { number: "50+", label: "Hospitals Using MediQ" },
    { number: "1M+", label: "Patients Served" }
  ]

  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Heart className="h-8 w-8 text-primary-600 mr-2" />
              <span className="text-2xl font-bold text-gray-900">MediQ</span>
            </div>
            <div className="flex space-x-4">
              <Link to="/login" className="btn-secondary">
                Patient Portal
              </Link>
              <Link to="/staff" className="btn-primary">
                Staff Login
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="gradient-bg text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            End the Long, Anxious Wait
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-blue-100 max-w-3xl mx-auto">
            MediQ transforms the chaotic patient journey into a seamless, predictable, and digital experience powered by AI.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/book" className="btn-medical text-lg px-8 py-4">
              Book Appointment
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
            <Link to="/patient" className="btn-secondary text-lg px-8 py-4">
              Check Queue Status
            </Link>
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">The Problem</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Hospital visits in cities like Lucknow aren't just about consultation; they're about hours wasted in uncertainty.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div className="card">
              <div className="flex items-center mb-4">
                <Users className="h-6 w-6 text-emergency-600 mr-2" />
                <h3 className="text-xl font-semibold text-gray-900">For Patients</h3>
              </div>
              <ul className="space-y-3 text-gray-600">
                <li className="flex items-start">
                  <Clock className="h-5 w-5 text-emergency-500 mr-2 mt-0.5" />
                  Manual token systems lead to long, unpredictable queues
                </li>
                <li className="flex items-start">
                  <Clock className="h-5 w-5 text-emergency-500 mr-2 mt-0.5" />
                  Delayed treatment and lost wages
                </li>
                <li className="flex items-start">
                  <Clock className="h-5 w-5 text-emergency-500 mr-2 mt-0.5" />
                  Higher risks of infection in overcrowded spaces
                </li>
              </ul>
            </div>
            
            <div className="card">
              <div className="flex items-center mb-4">
                <BarChart3 className="h-6 w-6 text-emergency-600 mr-2" />
                <h3 className="text-xl font-semibold text-gray-900">For Hospitals</h3>
              </div>
              <ul className="space-y-3 text-gray-600">
                <li className="flex items-start">
                  <Clock className="h-5 w-5 text-emergency-500 mr-2 mt-0.5" />
                  Severe operational inefficiency
                </li>
                <li className="flex items-start">
                  <Clock className="h-5 w-5 text-emergency-500 mr-2 mt-0.5" />
                  Overburdened staff and underutilized resources
                </li>
                <li className="flex items-start">
                  <Clock className="h-5 w-5 text-emergency-500 mr-2 mt-0.5" />
                  Low patient satisfaction scores
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Solution Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">The Solution</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              MediQ is an AI-powered platform that transforms the chaotic patient journey into a seamless, predictable, and digital experience.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <div 
                key={index}
                className={`card cursor-pointer transition-all duration-300 ${
                  activeFeature === index ? 'ring-2 ring-primary-500 shadow-lg' : ''
                }`}
                onClick={() => setActiveFeature(index)}
              >
                <div className="mb-4">{feature.icon}</div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Proven Results</h2>
            <p className="text-xl text-gray-600">MediQ delivers measurable improvements across all metrics</p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl font-bold text-primary-600 mb-2">{stat.number}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="medical-gradient text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-4">Ready to Transform Your Hospital Experience?</h2>
          <p className="text-xl mb-8 text-green-100 max-w-2xl mx-auto">
            Join thousands of patients and hospitals already using MediQ to eliminate wait times and improve care.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/book" className="bg-white text-medical-600 hover:bg-gray-100 font-semibold py-3 px-8 rounded-lg transition-all duration-200 shadow-sm hover:shadow-md">
              Get Started Today
            </Link>
            <Link to="/login" className="border-2 border-white text-white hover:bg-white hover:text-medical-600 font-semibold py-3 px-8 rounded-lg transition-all duration-200">
              Patient Login
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center mb-4 md:mb-0">
              <Heart className="h-8 w-8 text-primary-600 mr-2" />
              <span className="text-2xl font-bold">MediQ</span>
            </div>
            <div className="text-gray-400">
              © 2024 MediQ. All rights reserved. Transforming healthcare, one queue at a time.
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default LandingPage

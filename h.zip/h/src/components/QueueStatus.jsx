import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { 
  ArrowLeft, 
  Heart, 
  Clock, 
  Users, 
  MapPin, 
  Bell,
  CheckCircle,
  AlertCircle,
  Smartphone,
  RefreshCw,
  Zap
} from 'lucide-react'

const QueueStatus = () => {
  const [queueData, setQueueData] = useState({
    position: 0,
    estimatedWait: 0,
    totalInQueue: 0,
    currentServing: '',
    department: '',
    doctor: 'Dr. Rajesh Kumar',
    status: 'waiting', // waiting, called, completed
    notifications: true
  })

  const [checkInData, setCheckInData] = useState({
    name: '',
    phone: '',
    department: '',
    doctor: 'Dr. Rajesh Kumar',
    appointmentTime: '10:30 AM',
    tokenNumber: ''
  })

  // Load patient data from localStorage on component mount
  useEffect(() => {
    const patientData = JSON.parse(localStorage.getItem('patientData') || '{}')
    if (patientData.name) {
      setCheckInData(prev => ({
        ...prev,
        name: patientData.name,
        phone: patientData.phone
      }))
    } else {
      // Redirect to login if no patient data
      window.location.href = '/login'
    }
  }, [])

  // Simulate real-time updates and check for staff updates
  useEffect(() => {
    const interval = setInterval(() => {
      // Check for queue updates from staff
      const queuePatients = JSON.parse(localStorage.getItem('queuePatients') || '[]')
      if (queuePatients.length > 0) {
        // Find current patient in queue
        const currentPatientInQueue = queuePatients.find(p => 
          p.name === checkInData.name && p.phone === checkInData.phone
        )
        
        if (currentPatientInQueue) {
          // Check if patient is called
          if (currentPatientInQueue.status === 'called') {
            setQueueData(prev => ({ ...prev, status: 'called' }))
            alert(`🎉 It's your turn! Please proceed to ${currentPatientInQueue.department} department. Token: ${currentPatientInQueue.token}`)
          }
          
          // Update queue data
          const departmentPatients = queuePatients.filter(p => 
            p.department === currentPatientInQueue.department && 
            p.status !== 'completed'
          )
          const currentPosition = departmentPatients.findIndex(p => p.token === currentPatientInQueue.token) + 1
          
          setQueueData(prev => ({
            ...prev,
            position: currentPosition,
            estimatedWait: currentPatientInQueue.waitTime,
            department: currentPatientInQueue.department,
            currentServing: queuePatients.find(p => p.status === 'called')?.token || prev.currentServing,
            status: currentPatientInQueue.status === 'called' ? 'called' : 'waiting',
            totalInQueue: departmentPatients.length
          }))
          
          setCheckInData(prev => ({
            ...prev,
            tokenNumber: currentPatientInQueue.token,
            department: currentPatientInQueue.department
          }))
        } else {
          // Patient not found in queue
          setQueueData(prev => ({
            ...prev,
            position: 0,
            estimatedWait: 0,
            totalInQueue: 0,
            status: 'not-found'
          }))
        }
      }
    }, 5000) // Update every 5 seconds for faster updates

    return () => clearInterval(interval)
  }, [checkInData.name, checkInData.phone])

  const handleCheckIn = () => {
    setQueueData(prev => ({ ...prev, status: 'checked-in' }))
    alert('Successfully checked in! You will receive notifications about your queue status.')
  }

  const handleNotifyMe = () => {
    setQueueData(prev => ({ ...prev, notifications: !prev.notifications }))
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'waiting': return 'text-yellow-600 bg-yellow-100'
      case 'called': return 'text-green-600 bg-green-100'
      case 'completed': return 'text-blue-600 bg-blue-100'
      case 'not-found': return 'text-red-600 bg-red-100'
      default: return 'text-gray-600 bg-gray-100'
    }
  }

  const getStatusIcon = (status) => {
    switch (status) {
      case 'waiting': return <Clock className="h-5 w-5" />
      case 'called': return <Bell className="h-5 w-5" />
      case 'completed': return <CheckCircle className="h-5 w-5" />
      case 'not-found': return <AlertCircle className="h-5 w-5" />
      default: return <Clock className="h-5 w-5" />
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <nav className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Link to="/" className="flex items-center">
                <ArrowLeft className="h-5 w-5 text-gray-600 mr-2" />
                <Heart className="h-8 w-8 text-primary-600 mr-2" />
                <span className="text-2xl font-bold text-gray-900">MediQ</span>
              </Link>
            </div>
            <div className="flex items-center space-x-4">
              <button 
                onClick={() => window.location.reload()}
                className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <RefreshCw className="h-5 w-5" />
              </button>
              <div className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(queueData.status)}`}>
                <div className="flex items-center">
                  {getStatusIcon(queueData.status)}
                  <span className="ml-1 capitalize">{queueData.status.replace('-', ' ')}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Check-in Section */}
        <div className="card mb-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Virtual Check-in</h2>
            <div className="flex items-center text-sm text-gray-500">
              <Smartphone className="h-4 w-4 mr-1" />
              Real-time updates
            </div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Patient Name</label>
                <input
                  type="text"
                  value={checkInData.name}
                  onChange={(e) => setCheckInData({...checkInData, name: e.target.value})}
                  className="input-field"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                <input
                  type="tel"
                  value={checkInData.phone}
                  onChange={(e) => setCheckInData({...checkInData, phone: e.target.value})}
                  className="input-field"
                />
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Token Number</label>
                <input
                  type="text"
                  value={checkInData.tokenNumber}
                  onChange={(e) => setCheckInData({...checkInData, tokenNumber: e.target.value})}
                  className="input-field"
                />
              </div>
              <button
                onClick={handleCheckIn}
                className="btn-medical w-full"
              >
                <CheckCircle className="h-5 w-5 mr-2" />
                Check In Now
              </button>
            </div>
          </div>
        </div>

        {/* Queue Status */}
        <div className="card mb-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Your Queue Status</h2>
          
          {queueData.status === 'not-found' ? (
            <div className="text-center py-8">
              <AlertCircle className="h-16 w-16 text-red-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Patient Not Found in Queue</h3>
              <p className="text-gray-600 mb-4">You are not currently in any queue. Please contact staff to be added to the queue.</p>
              <Link to="/login" className="btn-primary">
                Go to Login
              </Link>
            </div>
          ) : (
            <>
              <div className="grid md:grid-cols-3 gap-6 mb-6">
                <div className="text-center p-4 bg-primary-50 rounded-lg">
                  <div className="text-3xl font-bold text-primary-600 mb-1">{queueData.position}</div>
                  <div className="text-sm text-gray-600">Position in Queue</div>
                </div>
                <div className="text-center p-4 bg-medical-50 rounded-lg">
                  <div className="text-3xl font-bold text-medical-600 mb-1">{queueData.estimatedWait}</div>
                  <div className="text-sm text-gray-600">Minutes Wait Time</div>
                </div>
                <div className="text-center p-4 bg-gray-50 rounded-lg">
                  <div className="text-3xl font-bold text-gray-600 mb-1">{queueData.totalInQueue}</div>
                  <div className="text-sm text-gray-600">Total in Queue</div>
                </div>
              </div>
            </>
          )}

          {queueData.status !== 'not-found' && (
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Currently Serving</span>
                <span className="text-lg font-bold text-gray-900">{queueData.currentServing}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-primary-600 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${queueData.totalInQueue > 0 ? ((queueData.totalInQueue - queueData.position + 1) / queueData.totalInQueue) * 100 : 0}%` }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Appointment Details */}
        <div className="card mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Appointment Details</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="flex items-center">
              <MapPin className="h-5 w-5 text-gray-400 mr-3" />
              <div>
                <div className="text-sm text-gray-500">Department</div>
                <div className="font-medium">{queueData.department}</div>
              </div>
            </div>
            <div className="flex items-center">
              <Users className="h-5 w-5 text-gray-400 mr-3" />
              <div>
                <div className="text-sm text-gray-500">Doctor</div>
                <div className="font-medium">{queueData.doctor}</div>
              </div>
            </div>
            <div className="flex items-center">
              <Clock className="h-5 w-5 text-gray-400 mr-3" />
              <div>
                <div className="text-sm text-gray-500">Appointment Time</div>
                <div className="font-medium">{checkInData.appointmentTime}</div>
              </div>
            </div>
            <div className="flex items-center">
              <Heart className="h-5 w-5 text-gray-400 mr-3" />
              <div>
                <div className="text-sm text-gray-500">Token Number</div>
                <div className="font-medium">{checkInData.tokenNumber}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Notifications */}
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Notifications</h3>
            <button
              onClick={handleNotifyMe}
              className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                queueData.notifications 
                  ? 'bg-primary-600 text-white' 
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              <Bell className="h-4 w-4 mr-2 inline" />
              {queueData.notifications ? 'Enabled' : 'Enable'}
            </button>
          </div>
          
          <div className="space-y-3">
            <div className="flex items-center p-3 bg-green-50 rounded-lg">
              <CheckCircle className="h-5 w-5 text-green-600 mr-3" />
              <div>
                <div className="font-medium text-green-900">Checked in successfully</div>
                <div className="text-sm text-green-700">You will receive updates about your queue position</div>
              </div>
            </div>
            
            <div className="flex items-center p-3 bg-blue-50 rounded-lg">
              <Zap className="h-5 w-5 text-blue-600 mr-3" />
              <div>
                <div className="font-medium text-blue-900">AI Prediction Active</div>
                <div className="text-sm text-blue-700">Our AI is monitoring queue patterns to give you accurate wait times</div>
              </div>
            </div>
            
            <div className="flex items-center p-3 bg-yellow-50 rounded-lg">
              <AlertCircle className="h-5 w-5 text-yellow-600 mr-3" />
              <div>
                <div className="font-medium text-yellow-900">Queue Moving Faster</div>
                <div className="text-sm text-yellow-700">Your wait time has been reduced by 5 minutes</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default QueueStatus

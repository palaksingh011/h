import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { 
  Heart, 
  Calendar, 
  Clock, 
  MapPin, 
  Users, 
  Bell,
  ArrowRight,
  CheckCircle,
  AlertCircle,
  Smartphone,
  Zap,
  BarChart3,
  LogOut,
  RefreshCw
} from 'lucide-react'

const PatientDashboard = () => {
  const [activeTab, setActiveTab] = useState('overview')
  const [patientData, setPatientData] = useState(null)
  const [lastUpdate, setLastUpdate] = useState(new Date())

  // Load patient data from localStorage
  useEffect(() => {
    const data = localStorage.getItem('patientData')
    if (data) {
      setPatientData(JSON.parse(data))
    } else {
      // Redirect to login if no patient data
      window.location.href = '/login'
    }
  }, [])

  // Simulate real-time updates and check for new queue data
  useEffect(() => {
    const interval = setInterval(() => {
      setLastUpdate(new Date())
      
      // Check for queue updates from staff
      const queuePatients = JSON.parse(localStorage.getItem('queuePatients') || '[]')
      if (queuePatients.length > 0) {
        // Find if current patient is in the queue
        const currentPatientInQueue = queuePatients.find(p => 
          p.name === patientData?.name && p.phone === patientData?.phone
        )
        
        if (currentPatientInQueue) {
          // Check if patient is called
          if (currentPatientInQueue.status === 'called') {
            alert(`🎉 It's your turn! Please proceed to ${currentPatientInQueue.department} department. Token: ${currentPatientInQueue.token}`)
          }
          
          // Update appointments with queue data
          setUpcomingAppointments(prev => prev.map(appointment => {
            if (appointment.department === currentPatientInQueue.department) {
              const departmentPatients = queuePatients.filter(p => 
                p.department === currentPatientInQueue.department && 
                p.status !== 'completed'
              )
              const currentPosition = departmentPatients.findIndex(p => p.token === currentPatientInQueue.token) + 1
              
              return {
                ...appointment,
                status: currentPatientInQueue.status === 'called' ? 'called' : 'confirmed',
                queuePosition: currentPosition,
                estimatedWait: currentPatientInQueue.waitTime,
                tokenNumber: currentPatientInQueue.token,
                confirmationStatus: 'confirmed',
                isMyTurn: currentPatientInQueue.status === 'called'
              }
            }
            return appointment
          }))
        }
      }
    }, 5000) // Update every 5 seconds for faster updates

    return () => clearInterval(interval)
  }, [patientData])

  const [upcomingAppointments, setUpcomingAppointments] = useState([
    {
      id: 1,
      department: 'Cardiology',
      doctor: 'Dr. Rajesh Kumar',
      date: '2024-01-20',
      time: '10:30 AM',
      status: 'confirmed',
      queuePosition: 3,
      estimatedWait: 15,
      tokenNumber: 'A-012',
      confirmationStatus: 'confirmed'
    },
    {
      id: 2,
      department: 'Neurology',
      doctor: 'Dr. Priya Sharma',
      date: '2024-01-22',
      time: '02:00 PM',
      status: 'pending',
      queuePosition: null,
      estimatedWait: null,
      tokenNumber: 'B-008',
      confirmationStatus: 'pending'
    }
  ])

  const recentVisits = [
    {
      id: 1,
      department: 'General Medicine',
      doctor: 'Dr. Suresh Kumar',
      date: '2024-01-15',
      diagnosis: 'Regular checkup',
      status: 'completed'
    },
    {
      id: 2,
      department: 'Orthopedics',
      doctor: 'Dr. Vikram Patel',
      date: '2024-01-10',
      diagnosis: 'Knee pain consultation',
      status: 'completed'
    }
  ]

  const notifications = [
    {
      id: 1,
      type: 'queue_update',
      title: 'Queue Position Update',
      message: 'You are now #3 in the queue. Estimated wait time: 15 minutes',
      time: '2 minutes ago',
      read: false,
      priority: 'high'
    },
    {
      id: 2,
      type: 'appointment_reminder',
      title: 'Appointment Reminder',
      message: 'Your appointment with Dr. Priya Sharma is tomorrow at 2:00 PM',
      time: '1 hour ago',
      read: true,
      priority: 'medium'
    },
    {
      id: 3,
      type: 'prescription_ready',
      title: 'Prescription Ready',
      message: 'Your prescription is ready for pickup at the pharmacy',
      time: '3 hours ago',
      read: true,
      priority: 'low'
    },
    {
      id: 4,
      type: 'confirmation',
      title: 'Appointment Confirmed',
      message: 'Your appointment with Dr. Rajesh Kumar has been confirmed for tomorrow',
      time: '5 hours ago',
      read: true,
      priority: 'medium'
    }
  ]

  const stats = [
    { label: 'Total Visits', value: '12', icon: <Users className="h-6 w-6" /> },
    { label: 'Upcoming Appointments', value: '2', icon: <Calendar className="h-6 w-6" /> },
    { label: 'Average Wait Time', value: '18 min', icon: <Clock className="h-6 w-6" /> },
    { label: 'Departments Visited', value: '5', icon: <MapPin className="h-6 w-6" /> }
  ]

  const handleLogout = () => {
    localStorage.removeItem('patientData')
    window.location.href = '/login'
  }

  const handleRefresh = () => {
    setLastUpdate(new Date())
    // Simulate refresh
    setUpcomingAppointments(prev => prev.map(appointment => {
      if (appointment.status === 'confirmed') {
        return {
          ...appointment,
          estimatedWait: Math.max(0, appointment.estimatedWait - Math.floor(Math.random() * 5))
        }
      }
      return appointment
    }))
  }

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <div className="space-y-6">
            {/* Real-time Status Banner */}
            <div className="card bg-gradient-to-r from-primary-50 to-medical-50 border-primary-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="animate-pulse-slow">
                    <Zap className="h-6 w-6 text-primary-600 mr-3" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Real-time Updates Active</h3>
                    <p className="text-sm text-gray-600">Last updated: {lastUpdate.toLocaleTimeString()}</p>
                  </div>
                </div>
                <button
                  onClick={handleRefresh}
                  className="btn-secondary text-sm py-2 px-4"
                >
                  <RefreshCw className="h-4 w-4 mr-1" />
                  Refresh
                </button>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {stats.map((stat, index) => (
                <div key={index} className="card text-center">
                  <div className="text-primary-600 mb-2 flex justify-center">{stat.icon}</div>
                  <div className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </div>
              ))}
            </div>

            {/* Upcoming Appointments with Real-time Updates */}
            <div className="card">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">Upcoming Appointments</h3>
                <Link to="/book" className="text-primary-600 hover:text-primary-700 text-sm font-medium">
                  Book New
                </Link>
              </div>
              <div className="space-y-4">
                {upcomingAppointments.map((appointment) => (
                  <div key={appointment.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center">
                        <Heart className="h-5 w-5 text-primary-600 mr-2" />
                        <span className="font-medium text-gray-900">{appointment.department}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          appointment.status === 'confirmed' 
                            ? 'bg-green-100 text-green-800' 
                            : appointment.status === 'called'
                            ? 'bg-red-100 text-red-800 animate-pulse'
                            : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {appointment.status === 'called' ? 'Your Turn!' : appointment.status}
                        </span>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          appointment.confirmationStatus === 'confirmed' 
                            ? 'bg-blue-100 text-blue-800' 
                            : 'bg-gray-100 text-gray-800'
                        }`}>
                          {appointment.confirmationStatus}
                        </span>
                      </div>
                    </div>
                    <div className="text-sm text-gray-600 mb-2">
                      <div className="flex items-center mb-1">
                        <Users className="h-4 w-4 mr-1" />
                        {appointment.doctor}
                      </div>
                      <div className="flex items-center mb-1">
                        <Calendar className="h-4 w-4 mr-1" />
                        {appointment.date} at {appointment.time}
                      </div>
                      <div className="flex items-center mb-1">
                        <Heart className="h-4 w-4 mr-1" />
                        Token: {appointment.tokenNumber}
                      </div>
                      {appointment.queuePosition && (
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-1" />
                          <span className="font-medium text-primary-600">
                            Position #{appointment.queuePosition}
                          </span>
                          <span className="mx-2">•</span>
                          <span className="font-medium text-medical-600">
                            {appointment.estimatedWait} min wait
                          </span>
                        </div>
                      )}
                    </div>
                    <div className="flex space-x-2">
                      <Link to="/queue" className="btn-primary text-sm py-2 px-4">
                        <Smartphone className="h-4 w-4 mr-1" />
                        Check Queue
                      </Link>
                      <button className="btn-secondary text-sm py-2 px-4">
                        Reschedule
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent Visits */}
            <div className="card">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Visits</h3>
              <div className="space-y-3">
                {recentVisits.map((visit) => (
                  <div key={visit.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <div className="font-medium text-gray-900">{visit.department}</div>
                      <div className="text-sm text-gray-600">{visit.doctor} • {visit.date}</div>
                      <div className="text-sm text-gray-500">{visit.diagnosis}</div>
                    </div>
                    <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">
                      {visit.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )

      case 'notifications':
        return (
          <div className="space-y-4">
            {notifications.map((notification) => (
              <div key={notification.id} className={`card ${!notification.read ? 'bg-blue-50 border-blue-200' : ''}`}>
                <div className="flex items-start">
                  <div className="flex-shrink-0 mr-3">
                    {notification.type === 'queue_update' && <Bell className="h-5 w-5 text-blue-600" />}
                    {notification.type === 'appointment_reminder' && <Calendar className="h-5 w-5 text-yellow-600" />}
                    {notification.type === 'prescription_ready' && <CheckCircle className="h-5 w-5 text-green-600" />}
                    {notification.type === 'confirmation' && <CheckCircle className="h-5 w-5 text-blue-600" />}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="font-medium text-gray-900">{notification.title}</h4>
                      <div className="flex items-center space-x-2">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          notification.priority === 'high' ? 'bg-red-100 text-red-800' :
                          notification.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-green-100 text-green-800'
                        }`}>
                          {notification.priority}
                        </span>
                        <span className="text-xs text-gray-500">{notification.time}</span>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600">{notification.message}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )

      case 'history':
        return (
          <div className="card">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Medical History</h3>
            <div className="space-y-4">
              {recentVisits.map((visit) => (
                <div key={visit.id} className="border-l-4 border-primary-500 pl-4 py-2">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-medium text-gray-900">{visit.department}</span>
                    <span className="text-sm text-gray-500">{visit.date}</span>
                  </div>
                  <div className="text-sm text-gray-600 mb-1">{visit.doctor}</div>
                  <div className="text-sm text-gray-500">{visit.diagnosis}</div>
                </div>
              ))}
            </div>
          </div>
        )

      default:
        return null
    }
  }

  if (!patientData) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Heart className="h-12 w-12 text-primary-600 mx-auto mb-4" />
          <div className="text-lg font-medium text-gray-900">Loading...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <nav className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Heart className="h-8 w-8 text-primary-600 mr-2" />
              <span className="text-2xl font-bold text-gray-900">MediQ</span>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-sm text-gray-600">
                Welcome, <span className="font-medium text-gray-900">{patientData.name}</span>
              </div>
              <button className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors">
                <Bell className="h-5 w-5" />
              </button>
              <button 
                onClick={handleLogout}
                className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <LogOut className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Quick Actions */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Link to="/book" className="card hover:shadow-md transition-shadow cursor-pointer text-center">
            <Calendar className="h-8 w-8 text-primary-600 mx-auto mb-2" />
            <div className="font-medium text-gray-900">Book Appointment</div>
          </Link>
          <Link to="/queue" className="card hover:shadow-md transition-shadow cursor-pointer text-center">
            <Smartphone className="h-8 w-8 text-medical-600 mx-auto mb-2" />
            <div className="font-medium text-gray-900">Check Queue</div>
          </Link>
          <div className="card hover:shadow-md transition-shadow cursor-pointer text-center">
            <BarChart3 className="h-8 w-8 text-emergency-600 mx-auto mb-2" />
            <div className="font-medium text-gray-900">View Reports</div>
          </div>
          <div className="card hover:shadow-md transition-shadow cursor-pointer text-center">
            <Users className="h-8 w-8 text-gray-600 mx-auto mb-2" />
            <div className="font-medium text-gray-900">Find Doctor</div>
          </div>
        </div>

        {/* Tabs */}
        <div className="mb-6">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex space-x-8">
              {[
                { id: 'overview', label: 'Overview' },
                { id: 'notifications', label: 'Notifications' },
                { id: 'history', label: 'History' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-2 px-1 border-b-2 font-medium text-sm ${
                    activeTab === tab.id
                      ? 'border-primary-500 text-primary-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Tab Content */}
        {renderTabContent()}
      </div>
    </div>
  )
}

export default PatientDashboard

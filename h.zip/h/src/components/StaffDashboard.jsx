import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { 
  Heart, 
  Users, 
  Clock, 
  BarChart3, 
  Bell,
  Settings,
  Zap,
  CheckCircle,
  AlertCircle,
  TrendingUp,
  TrendingDown,
  Activity,
  MapPin,
  Calendar,
  Plus,
  UserPlus,
  X
} from 'lucide-react'

const StaffDashboard = () => {
  const [activeTab, setActiveTab] = useState('overview')
  const [showAddPatientModal, setShowAddPatientModal] = useState(false)
  const [newPatient, setNewPatient] = useState({
    name: '',
    phone: '',
    department: '',
    priority: 'normal',
    symptoms: ''
  })

  const [queueStats, setQueueStats] = useState({
    totalPatients: 45,
    waitingPatients: 23,
    currentServing: 'A-015',
    averageWaitTime: 18,
    efficiency: 87
  })

  const [departments, setDepartments] = useState([
    { name: 'Cardiology', patients: 8, avgWait: 15, efficiency: 92 },
    { name: 'Neurology', patients: 6, avgWait: 22, efficiency: 85 },
    { name: 'Orthopedics', patients: 12, avgWait: 25, efficiency: 78 },
    { name: 'Pediatrics', patients: 9, avgWait: 12, efficiency: 95 },
    { name: 'General Medicine', patients: 10, avgWait: 18, efficiency: 88 }
  ])

  const [queueData, setQueueData] = useState({
    cardiology: [],
    neurology: []
  })

  // Load queue data from localStorage on component mount
  useEffect(() => {
    const loadQueueData = () => {
      const queuePatients = JSON.parse(localStorage.getItem('queuePatients') || '[]')
      // Only show patients who are waiting (not called or completed)
      const waitingPatients = queuePatients.filter(p => p.status === 'waiting')
      
      const cardiology = waitingPatients.filter(p => p.department === 'Cardiology')
      const neurology = waitingPatients.filter(p => p.department === 'Neurology')
      
      setQueueData({
        cardiology,
        neurology
      })
    }
    
    loadQueueData()
    
    // Refresh queue data every 5 seconds
    const interval = setInterval(loadQueueData, 5000)
    return () => clearInterval(interval)
  }, [])

  const handleAddPatient = () => {
    if (!newPatient.name || !newPatient.phone || !newPatient.department) {
      alert('Please fill in all required fields')
      return
    }

    // Generate new token
    const departmentPrefix = newPatient.department === 'Cardiology' ? 'A' : 'B'
    const nextNumber = Math.floor(Math.random() * 100) + 20
    const newToken = `${departmentPrefix}-${nextNumber.toString().padStart(3, '0')}`

    const patientToAdd = {
      token: newToken,
      name: newPatient.name,
      phone: newPatient.phone,
      waitTime: Math.floor(Math.random() * 30) + 5,
      priority: newPatient.priority,
      symptoms: newPatient.symptoms,
      department: newPatient.department,
      status: 'waiting',
      addedAt: new Date().toISOString()
    }

    // Store in localStorage
    const existingPatients = JSON.parse(localStorage.getItem('queuePatients') || '[]')
    existingPatients.push(patientToAdd)
    localStorage.setItem('queuePatients', JSON.stringify(existingPatients))

    // Update department stats
    setDepartments(prev => prev.map(dept => 
      dept.name === newPatient.department 
        ? { ...dept, patients: dept.patients + 1 }
        : dept
    ))

    // Update queue stats
    setQueueStats(prev => ({
      ...prev,
      totalPatients: prev.totalPatients + 1,
      waitingPatients: prev.waitingPatients + 1
    }))

    // Reset form
    setNewPatient({
      name: '',
      phone: '',
      department: '',
      priority: 'normal',
      symptoms: ''
    })
    setShowAddPatientModal(false)

    alert(`Patient ${newPatient.name} added to ${newPatient.department} queue with token ${newToken}`)
  }

  const handleCallNext = (department) => {
    const queuePatients = JSON.parse(localStorage.getItem('queuePatients') || '[]')
    const departmentPatients = queuePatients.filter(p => 
      p.department === department && p.status === 'waiting'
    )
    
    if (departmentPatients.length > 0) {
      const nextPatient = departmentPatients[0]
      
      // Update localStorage - mark patient as called
      const updatedPatients = queuePatients.map(patient => {
        if (patient.token === nextPatient.token) {
          return {
            ...patient,
            status: 'called',
            calledAt: new Date().toISOString()
          }
        }
        return patient
      })
      localStorage.setItem('queuePatients', JSON.stringify(updatedPatients))

      // Update stats
      setQueueStats(prev => ({
        ...prev,
        waitingPatients: prev.waitingPatients - 1,
        currentServing: nextPatient.token
      }))

      // Update department stats
      setDepartments(prev => prev.map(dept => 
        dept.name === department 
          ? { ...dept, patients: Math.max(0, dept.patients - 1) }
          : dept
      ))

      alert(`Calling ${nextPatient.name} (${nextPatient.token}) for consultation`)
    } else {
      alert(`No patients waiting in ${department} queue`)
    }
  }

  const handleCompleteAppointment = (patientToken) => {
    // Mark patient as completed
    const queuePatients = JSON.parse(localStorage.getItem('queuePatients') || '[]')
    const patientToRemove = queuePatients.find(p => p.token === patientToken)
    
    if (patientToRemove) {
      const updatedPatients = queuePatients.map(patient => {
        if (patient.token === patientToken) {
          return {
            ...patient,
            status: 'completed',
            completedAt: new Date().toISOString()
          }
        }
        return patient
      })
      localStorage.setItem('queuePatients', JSON.stringify(updatedPatients))

      // Update department stats
      setDepartments(prev => prev.map(dept => 
        dept.name === patientToRemove.department 
          ? { ...dept, patients: Math.max(0, dept.patients - 1) }
          : dept
      ))

      // Update queue stats
      setQueueStats(prev => ({
        ...prev,
        waitingPatients: prev.waitingPatients - 1
      }))

      alert(`Appointment completed for ${patientToRemove.name} (${patientToken})`)
    }
  }

  const recentActivities = [
    { id: 1, action: 'Patient A-012 checked in', time: '2 minutes ago', type: 'checkin' },
    { id: 2, action: 'Dr. Rajesh Kumar completed consultation', time: '5 minutes ago', type: 'completion' },
    { id: 3, action: 'Queue position updated for A-013', time: '8 minutes ago', type: 'update' },
    { id: 4, action: 'New appointment booked for tomorrow', time: '12 minutes ago', type: 'booking' },
    { id: 5, action: 'Patient A-010 called for consultation', time: '15 minutes ago', type: 'call' }
  ]

  const alerts = [
    { id: 1, type: 'warning', message: 'Cardiology queue is getting longer (8 patients)', priority: 'medium' },
    { id: 2, type: 'info', message: 'Dr. Priya Sharma is running 10 minutes behind schedule', priority: 'low' },
    { id: 3, type: 'success', message: 'Orthopedics efficiency improved by 5% today', priority: 'low' }
  ]

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <div className="space-y-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="card text-center">
                <Users className="h-8 w-8 text-primary-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">{queueStats.totalPatients}</div>
                <div className="text-sm text-gray-600">Total Patients</div>
              </div>
              <div className="card text-center">
                <Clock className="h-8 w-8 text-yellow-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">{queueStats.waitingPatients}</div>
                <div className="text-sm text-gray-600">Waiting</div>
              </div>
              <div className="card text-center">
                <Activity className="h-8 w-8 text-green-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">{queueStats.averageWaitTime}</div>
                <div className="text-sm text-gray-600">Avg Wait (min)</div>
              </div>
              <div className="card text-center">
                <TrendingUp className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">{queueStats.efficiency}%</div>
                <div className="text-sm text-gray-600">Efficiency</div>
              </div>
            </div>

            {/* Department Performance */}
            <div className="card">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Department Performance</h3>
              <div className="space-y-4">
                {departments.map((dept, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <Heart className="h-5 w-5 text-primary-600 mr-3" />
                      <div>
                        <div className="font-medium text-gray-900">{dept.name}</div>
                        <div className="text-sm text-gray-600">{dept.patients} patients in queue</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-gray-600">Avg Wait: {dept.avgWait} min</div>
                      <div className={`text-sm font-medium ${
                        dept.efficiency >= 90 ? 'text-green-600' :
                        dept.efficiency >= 80 ? 'text-yellow-600' : 'text-red-600'
                      }`}>
                        {dept.efficiency}% efficiency
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Current Queue Status */}
            <div className="card">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Current Queue Status</h3>
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">Currently Serving</span>
                  <span className="text-lg font-bold text-primary-600">{queueStats.currentServing}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div 
                    className="bg-primary-600 h-3 rounded-full transition-all duration-500"
                    style={{ width: `${(queueStats.waitingPatients / queueStats.totalPatients) * 100}%` }}
                  />
                </div>
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>0</span>
                  <span>{queueStats.waitingPatients} waiting</span>
                  <span>{queueStats.totalPatients} total</span>
                </div>
              </div>
            </div>
          </div>
        )

      case 'queue':
        return (
          <div className="space-y-6">
            {/* Queue Management */}
            <div className="card">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">Queue Management</h3>
                <div className="flex space-x-2">
                  <button 
                    onClick={() => setShowAddPatientModal(true)}
                    className="btn-medical text-sm py-2 px-4"
                  >
                    <UserPlus className="h-4 w-4 mr-1" />
                    Add Patient
                  </button>
                  <button className="btn-primary text-sm py-2 px-4">
                    <Zap className="h-4 w-4 mr-1" />
                    AI Optimize
                  </button>
                  <button className="btn-secondary text-sm py-2 px-4">
                    <Settings className="h-4 w-4 mr-1" />
                    Settings
                  </button>
                </div>
              </div>
              
              {/* Called Patients Section */}
              <div className="mb-6">
                <h4 className="text-md font-medium text-gray-900 mb-3">Currently Being Served</h4>
                <div className="space-y-2">
                  {(() => {
                    const queuePatients = JSON.parse(localStorage.getItem('queuePatients') || '[]')
                    const calledPatients = queuePatients.filter(p => p.status === 'called')
                    return calledPatients.map((patient, index) => (
                      <div key={patient.token} className="flex items-center justify-between p-3 bg-red-50 rounded-lg border border-red-200">
                        <div className="flex items-center space-x-3">
                          <div className="w-3 h-3 rounded-full bg-red-500 animate-pulse" />
                          <div>
                            <div className="font-medium text-gray-900">{patient.token}</div>
                            <div className="text-sm text-gray-600">{patient.name}</div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <div className="text-right">
                            <div className="text-sm font-medium text-red-600">Called</div>
                            <div className="text-xs text-gray-500">{patient.department}</div>
                          </div>
                          <button
                            onClick={() => handleCompleteAppointment(patient.token)}
                            className="btn-emergency text-xs py-1 px-2"
                          >
                            Complete
                          </button>
                        </div>
                      </div>
                    ))
                  })()}
                </div>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-medium text-gray-900">Cardiology Queue</h4>
                    <button 
                      onClick={() => handleCallNext('Cardiology')}
                      className="btn-medical text-xs py-1 px-3"
                    >
                      Call Next
                    </button>
                  </div>
                  <div className="space-y-2">
                    {queueData.cardiology?.map((patient, index) => (
                      <div key={patient.token} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className={`w-3 h-3 rounded-full ${
                            patient.priority === 'urgent' ? 'bg-red-500' :
                            patient.priority === 'emergency' ? 'bg-red-600' : 'bg-green-500'
                          }`} />
                          <div>
                            <div className="font-medium text-gray-900">{patient.token}</div>
                            <div className="text-sm text-gray-600">{patient.name}</div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <div className="text-right">
                            <div className="text-sm font-medium text-gray-900">{patient.waitTime} min</div>
                            <div className="text-xs text-gray-500">{patient.priority}</div>
                          </div>
                          {index === 0 && (
                            <button
                              onClick={() => handleCompleteAppointment(patient.token)}
                              className="btn-emergency text-xs py-1 px-2"
                            >
                              Complete
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-medium text-gray-900">Neurology Queue</h4>
                    <button 
                      onClick={() => handleCallNext('Neurology')}
                      className="btn-medical text-xs py-1 px-3"
                    >
                      Call Next
                    </button>
                  </div>
                  <div className="space-y-2">
                    {queueData.neurology?.map((patient, index) => (
                      <div key={patient.token} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className={`w-3 h-3 rounded-full ${
                            patient.priority === 'urgent' ? 'bg-red-500' :
                            patient.priority === 'emergency' ? 'bg-red-600' : 'bg-green-500'
                          }`} />
                          <div>
                            <div className="font-medium text-gray-900">{patient.token}</div>
                            <div className="text-sm text-gray-600">{patient.name}</div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <div className="text-right">
                            <div className="text-sm font-medium text-gray-900">{patient.waitTime} min</div>
                            <div className="text-xs text-gray-500">{patient.priority}</div>
                          </div>
                          {index === 0 && (
                            <button
                              onClick={() => handleCompleteAppointment(patient.token)}
                              className="btn-emergency text-xs py-1 px-2"
                            >
                              Complete
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="card">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <button 
                  onClick={() => handleCallNext('Cardiology')}
                  className="btn-medical text-sm py-3 px-4"
                >
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Call Cardiology
                </button>
                <button 
                  onClick={() => handleCallNext('Neurology')}
                  className="btn-medical text-sm py-3 px-4"
                >
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Call Neurology
                </button>
                <button 
                  onClick={() => setShowAddPatientModal(true)}
                  className="btn-secondary text-sm py-3 px-4"
                >
                  <UserPlus className="h-4 w-4 mr-2" />
                  Add Patient
                </button>
                <button className="btn-emergency text-sm py-3 px-4">
                  <AlertCircle className="h-4 w-4 mr-2" />
                  Emergency
                </button>
              </div>
            </div>
          </div>
        )

      case 'analytics':
        return (
          <div className="space-y-6">
            {/* Performance Charts */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="card">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Wait Time Trends</h3>
                <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
                  <div className="text-center text-gray-500">
                    <BarChart3 className="h-12 w-12 mx-auto mb-2" />
                    <div>Wait Time Chart</div>
                    <div className="text-sm">(Chart would be rendered here)</div>
                  </div>
                </div>
              </div>
              <div className="card">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Patient Flow</h3>
                <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
                  <div className="text-center text-gray-500">
                    <Activity className="h-12 w-12 mx-auto mb-2" />
                    <div>Patient Flow Chart</div>
                    <div className="text-sm">(Chart would be rendered here)</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Performance Metrics */}
            <div className="card">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Performance Metrics</h3>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600 mb-1">92%</div>
                  <div className="text-sm text-gray-600">Patient Satisfaction</div>
                  <TrendingUp className="h-4 w-4 text-green-600 mx-auto mt-1" />
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-1">18 min</div>
                  <div className="text-sm text-gray-600">Average Wait Time</div>
                  <TrendingDown className="h-4 w-4 text-green-600 mx-auto mt-1" />
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-purple-600 mb-1">87%</div>
                  <div className="text-sm text-gray-600">Resource Utilization</div>
                  <TrendingUp className="h-4 w-4 text-green-600 mx-auto mt-1" />
                </div>
              </div>
            </div>
          </div>
        )

      case 'alerts':
        return (
          <div className="space-y-4">
            {alerts.map((alert) => (
              <div key={alert.id} className={`card ${
                alert.type === 'warning' ? 'bg-yellow-50 border-yellow-200' :
                alert.type === 'info' ? 'bg-blue-50 border-blue-200' :
                'bg-green-50 border-green-200'
              }`}>
                <div className="flex items-start">
                  <div className="flex-shrink-0 mr-3">
                    {alert.type === 'warning' && <AlertCircle className="h-5 w-5 text-yellow-600" />}
                    {alert.type === 'info' && <Bell className="h-5 w-5 text-blue-600" />}
                    {alert.type === 'success' && <CheckCircle className="h-5 w-5 text-green-600" />}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <span className={`font-medium ${
                        alert.type === 'warning' ? 'text-yellow-900' :
                        alert.type === 'info' ? 'text-blue-900' :
                        'text-green-900'
                      }`}>
                        {alert.type.charAt(0).toUpperCase() + alert.type.slice(1)} Alert
                      </span>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        alert.priority === 'high' ? 'bg-red-100 text-red-800' :
                        alert.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-green-100 text-green-800'
                      }`}>
                        {alert.priority}
                      </span>
                    </div>
                    <p className={`text-sm ${
                      alert.type === 'warning' ? 'text-yellow-700' :
                      alert.type === 'info' ? 'text-blue-700' :
                      'text-green-700'
                    }`}>
                      {alert.message}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <nav className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Heart className="h-8 w-8 text-primary-600 mr-2" />
              <span className="text-2xl font-bold text-gray-900">MediQ Staff Portal</span>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-sm text-gray-600">
                <span className="font-medium text-gray-900">Dr. Admin</span> • Staff Dashboard
              </div>
              <button className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors">
                <Bell className="h-5 w-5" />
              </button>
              <button className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors">
                <Settings className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Tabs */}
        <div className="mb-6">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex space-x-8">
              {[
                { id: 'overview', label: 'Overview' },
                { id: 'queue', label: 'Queue Management' },
                { id: 'analytics', label: 'Analytics' },
                { id: 'alerts', label: 'Alerts' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-2 px-1 border-b-2 font-medium text-sm ${
                    activeTab === tab.id
                      ? 'border-primary-500 text-primary-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Tab Content */}
        {renderTabContent()}

        {/* Recent Activities */}
        <div className="card mt-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Activities</h3>
          <div className="space-y-3">
            {recentActivities.map((activity) => (
              <div key={activity.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <div className="flex-shrink-0 mr-3">
                    {activity.type === 'checkin' && <CheckCircle className="h-4 w-4 text-green-600" />}
                    {activity.type === 'completion' && <CheckCircle className="h-4 w-4 text-blue-600" />}
                    {activity.type === 'update' && <Bell className="h-4 w-4 text-yellow-600" />}
                    {activity.type === 'booking' && <Calendar className="h-4 w-4 text-purple-600" />}
                    {activity.type === 'call' && <Users className="h-4 w-4 text-red-600" />}
                  </div>
                  <span className="text-sm text-gray-900">{activity.action}</span>
                </div>
                <span className="text-xs text-gray-500">{activity.time}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Add Patient Modal */}
      {showAddPatientModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex min-h-screen items-center justify-center p-4">
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" onClick={() => setShowAddPatientModal(false)} />
            <div className="relative bg-white rounded-lg shadow-xl w-full max-w-md">
              <div className="flex items-center justify-between p-6 border-b border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900">Add Patient to Queue</h3>
                <button
                  onClick={() => setShowAddPatientModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Patient Name</label>
                  <input
                    type="text"
                    value={newPatient.name}
                    onChange={(e) => setNewPatient({...newPatient, name: e.target.value})}
                    className="input-field"
                    placeholder="Enter patient name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                  <input
                    type="tel"
                    value={newPatient.phone}
                    onChange={(e) => setNewPatient({...newPatient, phone: e.target.value})}
                    className="input-field"
                    placeholder="+91 98765 43210"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Department</label>
                  <select
                    value={newPatient.department}
                    onChange={(e) => setNewPatient({...newPatient, department: e.target.value})}
                    className="input-field"
                  >
                    <option value="">Select Department</option>
                    <option value="Cardiology">Cardiology</option>
                    <option value="Neurology">Neurology</option>
                    <option value="Orthopedics">Orthopedics</option>
                    <option value="Pediatrics">Pediatrics</option>
                    <option value="General Medicine">General Medicine</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Priority</label>
                  <select
                    value={newPatient.priority}
                    onChange={(e) => setNewPatient({...newPatient, priority: e.target.value})}
                    className="input-field"
                  >
                    <option value="normal">Normal</option>
                    <option value="urgent">Urgent</option>
                    <option value="emergency">Emergency</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Symptoms/Reason</label>
                  <textarea
                    value={newPatient.symptoms}
                    onChange={(e) => setNewPatient({...newPatient, symptoms: e.target.value})}
                    className="input-field"
                    rows={3}
                    placeholder="Describe symptoms or reason for visit"
                  />
                </div>
                <div className="flex justify-end space-x-3 pt-4">
                  <button
                    onClick={() => setShowAddPatientModal(false)}
                    className="btn-secondary"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleAddPatient}
                    className="btn-medical"
                  >
                    <UserPlus className="h-4 w-4 mr-2" />
                    Add Patient
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default StaffDashboard

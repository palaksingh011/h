import { useState } from 'react'
import { Link } from 'react-router-dom'
import { 
  ArrowLeft, 
  Calendar, 
  Clock, 
  User, 
  Phone, 
  Mail, 
  MapPin,
  Heart,
  CheckCircle,
  Zap,
  Smartphone
} from 'lucide-react'

const BookingSystem = () => {
  const [currentStep, setCurrentStep] = useState(1)
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    department: '',
    doctor: '',
    date: '',
    time: '',
    symptoms: '',
    priority: 'normal'
  })

  const departments = [
    { id: 'cardiology', name: 'Cardiology', icon: <Heart className="h-5 w-5" /> },
    { id: 'neurology', name: 'Neurology', icon: <Zap className="h-5 w-5" /> },
    { id: 'orthopedics', name: 'Orthopedics', icon: <User className="h-5 w-5" /> },
    { id: 'pediatrics', name: 'Pediatrics', icon: <Heart className="h-5 w-5" /> },
    { id: 'dermatology', name: 'Dermatology', icon: <User className="h-5 w-5" /> },
    { id: 'general', name: 'General Medicine', icon: <User className="h-5 w-5" /> }
  ]

  const doctors = {
    cardiology: ['Dr. Rajesh Kumar', 'Dr. Priya Sharma'],
    neurology: ['Dr. Amit Singh', 'Dr. Neha Gupta'],
    orthopedics: ['Dr. Vikram Patel', 'Dr. Sunita Reddy'],
    pediatrics: ['Dr. Anil Verma', 'Dr. Kavita Joshi'],
    dermatology: ['Dr. Rohit Agarwal', 'Dr. Meera Singh'],
    general: ['Dr. Suresh Kumar', 'Dr. Deepa Sharma']
  }

  const timeSlots = [
    '09:00 AM', '09:30 AM', '10:00 AM', '10:30 AM', '11:00 AM', '11:30 AM',
    '12:00 PM', '12:30 PM', '02:00 PM', '02:30 PM', '03:00 PM', '03:30 PM',
    '04:00 PM', '04:30 PM', '05:00 PM', '05:30 PM'
  ]

  const handleNext = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1)
    }
  }

  const handlePrev = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleSubmit = () => {
    // Simulate AI-powered scheduling
    const estimatedWaitTime = Math.floor(Math.random() * 30) + 5 // 5-35 minutes
    alert(`Appointment booked! Your estimated wait time is ${estimatedWaitTime} minutes. Please login to track your queue status.`)
    // Redirect to login
    window.location.href = '/login'
  }

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Personal Information</h2>
              <p className="text-gray-600">Tell us about yourself to get started</p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="input-field"
                  placeholder="Enter your full name"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  className="input-field"
                  placeholder="+91 98765 43210"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="input-field"
                  placeholder="your.email@example.com"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Priority Level</label>
                <select
                  value={formData.priority}
                  onChange={(e) => setFormData({...formData, priority: e.target.value})}
                  className="input-field"
                >
                  <option value="normal">Normal</option>
                  <option value="urgent">Urgent</option>
                  <option value="emergency">Emergency</option>
                </select>
              </div>
            </div>
          </div>
        )

      case 2:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Select Department</h2>
              <p className="text-gray-600">Choose the department that best fits your needs</p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {departments.map((dept) => (
                <div
                  key={dept.id}
                  className={`card cursor-pointer transition-all duration-200 ${
                    formData.department === dept.id ? 'ring-2 ring-primary-500 bg-primary-50' : 'hover:shadow-md'
                  }`}
                  onClick={() => setFormData({...formData, department: dept.id})}
                >
                  <div className="flex items-center">
                    <div className="text-primary-600 mr-3">{dept.icon}</div>
                    <span className="font-medium text-gray-900">{dept.name}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )

      case 3:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Select Doctor & Time</h2>
              <p className="text-gray-600">Choose your preferred doctor and appointment time</p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Select Doctor</label>
                <select
                  value={formData.doctor}
                  onChange={(e) => setFormData({...formData, doctor: e.target.value})}
                  className="input-field"
                >
                  <option value="">Choose a doctor</option>
                  {formData.department && doctors[formData.department]?.map((doctor) => (
                    <option key={doctor} value={doctor}>{doctor}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Preferred Date</label>
                <input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({...formData, date: e.target.value})}
                  className="input-field"
                  min={new Date().toISOString().split('T')[0]}
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Available Time Slots</label>
              <div className="grid grid-cols-4 md:grid-cols-6 gap-2">
                {timeSlots.map((time) => (
                  <button
                    key={time}
                    className={`py-2 px-3 rounded-lg text-sm font-medium transition-all duration-200 ${
                      formData.time === time 
                        ? 'bg-primary-600 text-white' 
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                    onClick={() => setFormData({...formData, time})}
                  >
                    {time}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )

      case 4:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Symptoms & Final Details</h2>
              <p className="text-gray-600">Help us prepare for your visit</p>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Describe your symptoms</label>
              <textarea
                value={formData.symptoms}
                onChange={(e) => setFormData({...formData, symptoms: e.target.value})}
                className="input-field"
                rows={4}
                placeholder="Please describe your symptoms or reason for the visit..."
              />
            </div>
            
            <div className="card bg-primary-50 border-primary-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Appointment Summary</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Name:</span>
                  <span className="font-medium">{formData.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Phone:</span>
                  <span className="font-medium">{formData.phone}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Department:</span>
                  <span className="font-medium">{departments.find(d => d.id === formData.department)?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Doctor:</span>
                  <span className="font-medium">{formData.doctor}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Date & Time:</span>
                  <span className="font-medium">{formData.date} at {formData.time}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Priority:</span>
                  <span className={`font-medium ${
                    formData.priority === 'emergency' ? 'text-emergency-600' :
                    formData.priority === 'urgent' ? 'text-yellow-600' : 'text-gray-600'
                  }`}>
                    {formData.priority.charAt(0).toUpperCase() + formData.priority.slice(1)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <nav className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Link to="/" className="flex items-center">
                <ArrowLeft className="h-5 w-5 text-gray-600 mr-2" />
                <Heart className="h-8 w-8 text-primary-600 mr-2" />
                <span className="text-2xl font-bold text-gray-900">MediQ</span>
              </Link>
            </div>
            <div className="text-sm text-gray-500">
              Step {currentStep} of 4
            </div>
          </div>
        </div>
      </nav>

      {/* Progress Bar */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center py-4">
            {[1, 2, 3, 4].map((step) => (
              <div key={step} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                  step <= currentStep 
                    ? 'bg-primary-600 text-white' 
                    : 'bg-gray-200 text-gray-500'
                }`}>
                  {step < currentStep ? <CheckCircle className="h-5 w-5" /> : step}
                </div>
                {step < 4 && (
                  <div className={`w-16 h-1 mx-2 ${
                    step < currentStep ? 'bg-primary-600' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="card">
          {renderStep()}
          
          {/* Navigation Buttons */}
          <div className="flex justify-between mt-8 pt-6 border-t border-gray-200">
            <button
              onClick={handlePrev}
              disabled={currentStep === 1}
              className={`btn-secondary ${currentStep === 1 ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              Previous
            </button>
            
            {currentStep < 4 ? (
              <button
                onClick={handleNext}
                className="btn-primary"
                disabled={
                  (currentStep === 1 && (!formData.name || !formData.phone || !formData.email)) ||
                  (currentStep === 2 && !formData.department) ||
                  (currentStep === 3 && (!formData.doctor || !formData.date || !formData.time))
                }
              >
                Next
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                className="btn-medical"
              >
                <Smartphone className="h-5 w-5 mr-2" />
                Book Appointment
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default BookingSystem

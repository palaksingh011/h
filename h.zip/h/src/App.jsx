import { Routes, Route } from 'react-router-dom'
import LandingPage from './components/LandingPage'
import PatientLogin from './components/PatientLogin'
import PatientDashboard from './components/PatientDashboard'
import BookingSystem from './components/BookingSystem'
import QueueStatus from './components/QueueStatus'
import StaffDashboard from './components/StaffDashboard'
import './App.css'

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<PatientLogin />} />
        <Route path="/patient" element={<PatientDashboard />} />
        <Route path="/book" element={<BookingSystem />} />
        <Route path="/queue" element={<QueueStatus />} />
        <Route path="/staff" element={<StaffDashboard />} />
      </Routes>
    </div>
  )
}

export default App